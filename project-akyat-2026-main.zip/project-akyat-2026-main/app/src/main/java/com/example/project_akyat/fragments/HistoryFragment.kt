package com.example.project_akyat.fragments

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.project_akyat.R
import com.example.project_akyat.adapters.HikeAdapter
import com.example.project_akyat.model.HikeRepository
import com.example.project_akyat.model.local.HikeEntity
import com.example.project_akyat.model.local.db.AppDatabase
import com.example.project_akyat.model.remote.toEntity
import com.example.project_akyat.model.remote.toRequest
import com.example.project_akyat.network.RetrofitClient
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class HistoryFragment : Fragment() {

    private lateinit var rvHikeHistory: RecyclerView
    private lateinit var tvEmptyState: TextView
    private lateinit var repo: HikeRepository
    private lateinit var hikeAdapter: HikeAdapter
    private lateinit var tvHikeCount: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_history, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rvHikeHistory = view.findViewById(R.id.rvHikeHistory)
        tvEmptyState = view.findViewById(R.id.tvEmptyState)
        tvHikeCount = view.findViewById(R.id.tvHikeCount)

        val dao = AppDatabase.getInstance(requireContext()).hikeDao()
        repo = HikeRepository(dao)

        syncFromServer()
        setupRecyclerView()
        observeHikes()
    }

    private fun setupRecyclerView() {
        hikeAdapter = HikeAdapter(
            onUploadClick = { hike ->
                if (isOnline()) {
                    uploadHike(hike)
                } else {
                    Toast.makeText(requireContext(), "No internet connection", Toast.LENGTH_SHORT).show()
                }
            },
            onDeleteClick = { hike ->
                android.app.AlertDialog.Builder(requireContext())
                    .setTitle("Delete Hike")
                    .setMessage("Are you sure you want to delete this hike?")
                    .setPositiveButton("Delete") { _, _ ->
                        when {
                            !hike.synced || hike.serverId == null -> {
                                viewLifecycleOwner.lifecycleScope.launch {
                                    repo.delete(hike)
                                    Toast.makeText(requireContext(), "Deleted!", Toast.LENGTH_SHORT).show()
                                }
                            }
                            !isOnline() -> {
                                Toast.makeText(requireContext(), "No internet connection", Toast.LENGTH_SHORT).show()
                            }
                            else -> deleteHike(hike)
                        }
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        )

        rvHikeHistory.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = hikeAdapter
        }
    }

    @SuppressLint("SetTextI18n")
    private fun observeHikes() {
        viewLifecycleOwner.lifecycleScope.launch {
            repo.allHikes.collectLatest { hikes ->
                tvHikeCount.text = "${hikes.size} hikes"

                if (hikes.isEmpty()) {
                    tvEmptyState.visibility = View.VISIBLE
                    rvHikeHistory.visibility = View.GONE
                } else {
                    tvEmptyState.visibility = View.GONE
                    rvHikeHistory.visibility = View.VISIBLE
                    hikeAdapter.submitList(hikes)
                }
            }
        }
    }

    private fun uploadHike(hike: HikeEntity) {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val api = RetrofitClient.create(requireContext())
                val response = api.createHike(hike.toRequest())
                if (response.isSuccessful) {
                    val serverId = response.body()?.id
                    android.util.Log.d("UPLOAD", "serverId: $serverId, hike.id: ${hike.id}")
                    repo.update(hike.copy(synced = true, serverId = serverId))
                    Toast.makeText(requireContext(), "Uploaded!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(requireContext(), "Upload failed", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun syncFromServer() {
        if (!isOnline()) return
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val api = RetrofitClient.create(requireContext())
                val response = api.getHikes()
                if (response.isSuccessful) {
                    response.body()?.forEach { hikeRequest ->
                        val existing = repo.findByServerId(hikeRequest.id!!)
                        repo.upsert(hikeRequest.toEntity(localId = existing?.id ?: 0))
                    }
                }
            } catch (e: Exception) {
                // silent fail
            }
        }
    }

    private fun deleteHike(hike: HikeEntity) {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                android.util.Log.d("DELETE", "serverId: ${hike.serverId}")
                val api = RetrofitClient.create(requireContext())
                val response = api.deleteHike(hike.serverId!!)
                android.util.Log.d("DELETE", "response code: ${response.code()}")
                android.util.Log.d("DELETE", "response body: ${response.errorBody()?.string()}")
                if (response.isSuccessful) {
                    repo.delete(hike)
                    Toast.makeText(requireContext(), "Deleted!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(requireContext(), "Delete failed", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                android.util.Log.e("DELETE", "exception: ${e.message}")
                Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun isOnline(): Boolean {
        val cm = requireContext().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }
}